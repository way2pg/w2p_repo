const handler = require('feathers-errors/handler');
const notFound = require('feathers-errors/not-found');

const upload = require('./upload');

const download = require('./download');

const deleteImage = require('./delete');

module.exports = function () {
  // Add your custom middleware here. Remember, that
  // in Express the order matters, `notFound` and
  // the error handler have to go last.
  const app = this;

  app.use('/image/upload', upload());

  app.use('/image/download/:id', download());

  app.use('/image/delete/:id', deleteImage());

  app.use(notFound());
  app.use(handler());
};
