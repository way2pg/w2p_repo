module.exports = function (options = {}) {
  return function download(req, res, next) {
    console.log('download middleware is running');
    next();
  };
};
