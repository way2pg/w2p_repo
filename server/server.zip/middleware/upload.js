module.exports = function (options = {}) {
  return function upload(req, res, next) {
    console.log('upload middleware is running');
    next();
  };
};
