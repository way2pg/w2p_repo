module.exports = function (options = {}) {
  return function deleteImage(req, res, next) {
    console.log('delete middleware is running');
    next();
  };
};
