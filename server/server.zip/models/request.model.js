module.exports = function (app) {
  const mongoose = app.get('mongooseClient');
  const Schema = mongoose.Schema;
  const request = new mongoose.Schema(
  {
    name: {
      type: String,
      required: false
    },
    mobile: {
      type: String,
      required: false
    },
    email: {
      type: String,
      required: false
    },
    comments: {
      type: String,
      trim: true,
      required: false
    },
    request: {
      type: String,
      required: false
    },
    request_type: {
      type: String,
      required: false
    },
    request_data: [
      {
        start_date: Date,
        end_date: Date,
        dinner: Boolean,
        lunch: Boolean,
        breakfast: Boolean
      }
    ],
    status: {
      type: String,
      required: false
    },
    approver: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    approver_comments: {
      type: String,
      required: false
    },
    createdAt: {type: Date, 'default': Date.now},
    updatedAt: {type: Date, 'default': Date.now},
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
  });

  return mongoose.model('request', request);
};
