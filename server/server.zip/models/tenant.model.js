module.exports = function (app) {
  const mongoose = app.get('mongooseClient');
  const Schema = mongoose.Schema;
  const tenant = new mongoose.Schema( {
    pgdetails: {
      type: Schema.Types.ObjectId,
      ref: 'pgdetails'
    },
    tenantImg: {
      type: String,
      required: false
    },
    referredBy: {
      type: String,
      required: false
    },
    referralCode: {
      type: String,
      required: false
    },
    idproofs: {
      type: String,
      required: false
    },
    joinedPackage: {
      type: String,
      required: false
    },
    advanceAmount: {
      type: String,
      required: false
    },
    paidAmount: {
      type: String,
      required: false
    },
    joinedDate: {
      type: String,
      required: false
    },
    proofs:{
      type:Object,
      required:false
    },
    roomtype:{
      type:String,
      required:false
    },
    pgowner: {
      type: Schema.Types.ObjectId,
      ref: 'PGOwners'
    },
    tenant: {
      type: Schema.Types.ObjectId,
      ref: 'user'
    },
    createdAt: {
      type: Date,
    },
    updatedAt: {
      type: Date,
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'user'
    },
    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'user'
    },
    deleted:{
      type:Boolean,
      reqired:false,
      default: false
    },
    deletedBy:{
      type: Schema.Types.ObjectId,
      ref: 'user',
      select: false
    },
  });

  return mongoose.model('tenant', tenant);
};
