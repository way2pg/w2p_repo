module.exports = function (app) {
  const mongoose = app.get('mongooseClient');
  const Schema = mongoose.Schema;
  const groups = new mongoose.Schema( {
    name: {
      type: String,
      required: false
    },
    members: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    createdAt: {
      type: Date,
    },
    updatedAt: {
      type: Date,
    },
    createdBy:{
      type: Schema.Types.ObjectId,
      ref: 'user',
      select: false
    },
    updatedBy:{
      type: Schema.Types.ObjectId,
      ref: 'user',
      select: false
    }
  });

  return mongoose.model('groups', groups);
};
