const { authenticate } = require('feathers-authentication').hooks;
const hooks = require('feathers-hooks');
const { iff, populate,client,setCreatedAt, setUpdatedAt } = require('feathers-hooks-common');
const staffmember = {
  service: '/api/users',
  field: 'staffmember'
};
module.exports = {
  before: {
    all: [ authenticate('jwt') ],
    find: [],
    get: [],
    create: [setCreatedAt('createdAt'),setUpdatedAt('updatedAt')],
    update: [setUpdatedAt('updatedAt')],
   patch: [
    setUpdatedAt('updatedAt')
  ],
    remove: []
  },

  after: {
    all: [populate('staffmember', staffmember)],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  }
};
