// Initializes the `tenant` service on path `/api/tenants`
const createService = require('feathers-mongoose');
const createModel = require('../../models/tenant.model');
const hooks = require('./tenant.hooks');
const filters = require('./tenant.filters');

module.exports = function () {
  const app = this;
  const Model = createModel(app);
  const paginate = app.get('paginate');

  const options = {
    name: 'tenant',
    Model,
    paginate
  };

  // Initialize our service with any options it requires
  app.use('/api/tenants', createService(options));

  // Get our initialized service so that we can register hooks and filters
  const service = app.service('api/tenants');

  service.hooks(hooks);

  if (service.filter) {
    service.filter(filters);
  }
};
