const { authenticate } = require('feathers-authentication').hooks;
const hooks = require('feathers-hooks');
const { iff, populate,client,setCreatedAt, setUpdatedAt } = require('feathers-hooks-common');
const tenant = {
  service: '/api/users',
  field: 'tenant'
};

const pgdetails = {
  service: '/api/pgdetails',
  field: 'pgdetails'
};

module.exports = {
  before: {
    all: [ authenticate('jwt') ],
    find: [],
    get: [],
    create: [setCreatedAt('createdAt'),setUpdatedAt('updatedAt')],
    update: [setUpdatedAt('updatedAt')],
    patch: [setUpdatedAt('updatedAt')],
    remove: []
  },

  after: {
    all: [populate('tenant', tenant),populate('pgdetails', pgdetails)],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  }
};
