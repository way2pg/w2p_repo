
const users = require('./users/users.service.js');
const tenant = require('./tenant/tenant.service.js');
const staffMembers = require('./staff-members/staff-members.service.js');
const rules = require('./rules/rules.service.js');
const rooms = require('./rooms/rooms.service.js');
const request = require('./request/request.service.js');
const referrals = require('./referrals/referrals.service.js');
const pgdetails = require('./pgdetails/pgdetails.service.js');
const pageViews = require('./page-views/page-views.service.js');
const likDislikes = require('./lik-dislikes/lik-dislikes.service.js');
const configuration = require('./configuration/configuration.service.js');
const groups = require('./groups/groups.service.js');
const feedback = require('./feedback/feedback.service.js');
const faqs = require('./faqs/faqs.service.js');
const comments = require('./comments/comments.service.js');
module.exports = function () {
  const app = this; // eslint-disable-line no-unused-vars  
  app.configure(users);
  app.configure(tenant);
  app.configure(staffMembers);
  app.configure(rules);
  app.configure(rooms);
  app.configure(request);
  app.configure(referrals);
  app.configure(pgdetails);
  app.configure(pageViews);
  app.configure(likDislikes);
  app.configure(configuration);
  app.configure(groups);
  app.configure(feedback);
  app.configure(faqs);
  app.configure(comments);
};
