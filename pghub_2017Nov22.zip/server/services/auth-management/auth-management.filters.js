module.exports = function (data, connection, hook) {
  return data;
};
